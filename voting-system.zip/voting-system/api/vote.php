<?php
require '../config.php';
require '_helpers.php';

$voter = requireAuth(); // exits on error
$input = json_decode(file_get_contents('php://input'), true);
$teamId = $input['teamId'] ?? 0;

// atomic vote
$pdo->beginTransaction();
$pdo->prepare("UPDATE team SET votes = votes + 1 WHERE id = ?")->execute([$teamId]);
$pdo->prepare("UPDATE voter SET voted = 1 WHERE id = ?")->execute([$voter['id']]);
$pdo->prepare("INSERT INTO vote (team_id, voter_id) VALUES (?, ?)")
     ->execute([$teamId, $voter['id']]);
$pdo->commit();

sendJSON(['success' => true]);