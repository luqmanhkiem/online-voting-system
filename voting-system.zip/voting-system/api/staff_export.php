<?php
require '../config.php';
if (!isset($_SESSION['staff'])) { http_response_code(401); exit('Login required'); }

header('Content-Type: application/json');
$rows = $pdo->query("SELECT name,votes FROM team ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);

// 1) Build CSV string
$csv = "Team,Votes\n";
foreach ($rows as $r) $csv .= "{$r['name']},{$r['votes']}\n";

// 2) Push to Google-Sheet via Google Apps Script Web App
$scriptUrl = 'https://script.google.com/macros/s/AKfycbyZ6ZIzINFdMZL_0_bQYlbSMe8uh0Nloxe_NO7Iy_86Q9AgbsGorjjlxAb8u7KVM6W2/exec'; // replace!
$options = [
  'http' => [
    'method'  => 'POST',
    'header'  => "Content-type: application/json\r\n",
    'content' => json_encode(['csv' => $csv])
  ]
];
$ctx  = stream_context_create($options);
$resp = file_get_contents($scriptUrl, false, $ctx);

json(['sheetUrl' => json_decode($resp, true)['url'] ?? '']);