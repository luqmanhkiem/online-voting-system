<?php
require '../config.php';
if (!isset($_SESSION['staff'])) { http_response_code(401); exit('Login required'); }

$rows = $pdo->query("SELECT id,name,votes FROM team ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
json($rows);