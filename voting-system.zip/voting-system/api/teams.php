<?php
require '../config.php';
$rows = $pdo->query("SELECT id,name,votes FROM team ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($rows);