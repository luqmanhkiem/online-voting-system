<?php
require '../config.php';
$rows = $pdo->query("SELECT name,votes FROM team ORDER BY id")->fetchAll(PDO::FETCH_ASSOC);

// CSV for Google-Sheet import
header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="vote_results.csv"');
$fp = fopen('php://output', 'w');
fputcsv($fp, ['Team', 'Votes']);
foreach ($rows as $r) fputcsv($fp, $r);