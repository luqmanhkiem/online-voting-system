<?php
function sendJSON($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data, JSON_PRETTY_PRINT);
    exit;
}

function requireAuth() {
    $headers = getallheaders();
    if (!isset($headers['Authorization'])) {
        sendJSON(['error' => 'No token'], 401);
    }
    [$type, $token] = explode(' ', $headers['Authorization']);
    if ($type !== 'Bearer') sendJSON(['error' => 'Bad token'], 401);

    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM voter WHERE matric_no = ? AND voted = 0");
    $stmt->execute([$token]);     // token = matric_no (demo)
    $voter = $stmt->fetch();
    if (!$voter) sendJSON(['error' => 'Invalid or already voted'], 401);
    return $voter;
}