<?php
require '../config.php';
session_start(); // ✅ Must start session before using $_SESSION

// Read JSON input
$in = json_decode(file_get_contents('php://input'), true);
$user = $in['username'] ?? '';
$pass = $in['password'] ?? '';

// Query staff table
$stmt = $pdo->prepare("SELECT * FROM staff WHERE username = ?");
$stmt->execute([$user]);
$staff = $stmt->fetch();

if ($staff && $pass === $staff['password']) {
    // ✅ Save staff ID in session
    $_SESSION['staff'] = $staff['id'];

    // ✅ Return token (you can use session id as token)
    echo json_encode(['token' => $staff['id']]);
} else {
    // ❌ Invalid credentials
    http_response_code(401);
    echo json_encode(['error' => 'Invalid credentials']);
}
?>
