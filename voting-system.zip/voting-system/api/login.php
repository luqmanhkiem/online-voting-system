<?php
require '../config.php';
require '_helpers.php';

$input = json_decode(file_get_contents('php://input'), true);
$matric = $input['matric_no'] ?? '';

$stmt = $pdo->prepare("SELECT * FROM voter WHERE matric_no = ?");
$stmt->execute([$matric]);
$voter = $stmt->fetch();

if (!$voter) sendJSON(['error' => 'Not found'], 404);
sendJSON(['token' => $voter['matric_no']]); // simple token