<?php
session_start();
$host = 'localhost'; $db = 'vote_db'; $user = 'root'; $pass = '';
$pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4",
               $user, $pass,
               [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);

function json($data, $status = 200) {
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($data, JSON_PRETTY_PRINT);
    exit;
}