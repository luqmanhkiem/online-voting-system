DROP TABLE IF EXISTS staff;

CREATE TABLE staff (
  id INT PRIMARY KEY AUTO_INCREMENT,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL
);

INSERT INTO staff (username, password) VALUES 
('Amir', '12345678'),
('Daniel', '12345678');
