// Voter.java
package com.bitp.model;
import jakarta.persistence.*;
@Entity
public class Voter {
    @Id @GeneratedValue (strategy = GenerationType.IDENTITY)
    private Integer id;
    @Column(unique = true) private String matricNo;
    private Boolean voted = false;

    public Voter() {}
    public Voter(String matricNo, Boolean voted) { this.matricNo = matricNo; this.voted = voted; }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getMatricNo() { return matricNo; }
    public void setMatricNo(String matricNo) { this.matricNo = matricNo; }
    public Boolean getVoted() { return voted; }
    public void setVoted(Boolean voted) { this.voted = voted; }
}