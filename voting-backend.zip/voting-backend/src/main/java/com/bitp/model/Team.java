// Team.java
package com.bitp.model;
import jakarta.persistence.*;
@Entity
public class Team {
    @Id @GeneratedValue (strategy = GenerationType.IDENTITY)
    private Integer id;
    private String name;
    private Integer votes = 0;

    public Team() {}
    public Team(String name, Integer votes) { this.name = name; this.votes = votes; }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public Integer getVotes() { return votes; }
    public void setVotes(Integer votes) { this.votes = votes; }
}