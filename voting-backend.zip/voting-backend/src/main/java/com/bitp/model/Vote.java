package com.bitp.model;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
public class Vote {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @ManyToOne
    private Team team;

    @OneToOne
    private Voter voter;

    private Instant votedAt = Instant.now();

    public Vote() {}
    public Vote(Team team, Voter voter) {
        this.team = team;
        this.voter = voter;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public Team getTeam() { return team; }
    public void setTeam(Team team) { this.team = team; }
    public Voter getVoter() { return voter; }
    public void setVoter(Voter voter) { this.voter = voter; }
    public Instant getVotedAt() { return votedAt; }
    public void setVotedAt(Instant votedAt) { this.votedAt = votedAt; }
}