// VotingBackendApplication.java (add CommandLineRunner to seed data)
package com.bitp;

import com.bitp.model.*;
import com.bitp.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.security.crypto.password.PasswordEncoder;

@SpringBootApplication
@EntityScan("com.bitp.model")
public class VotingBackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(VotingBackendApplication.class, args);
    }

    @Bean
    CommandLineRunner initDatabase(VoterRepository voterRepo, TeamRepository teamRepo, StaffRepository staffRepo, PasswordEncoder encoder) {
        return args -> {
            // Seed voters if they don't exist
            if (voterRepo.count() == 0) {
                voterRepo.save(new Voter("B032310678", false));
                voterRepo.save(new Voter("B032310679", false));
            }
            
            // Seed teams if they don't exist
            if (teamRepo.count() == 0) {
                teamRepo.save(new Team("Team A", 0));
                teamRepo.save(new Team("Team B", 0));
                teamRepo.save(new Team("Team C", 0));
            }
            
            // Seed staff if they don't exist
            if (staffRepo.findByUsername("admin").isEmpty()) {
                staffRepo.save(new Staff("admin", encoder.encode("admin123")));
            }
        };
    }
    }