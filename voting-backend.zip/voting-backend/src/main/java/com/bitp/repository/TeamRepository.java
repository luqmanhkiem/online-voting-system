package com.bitp.repository;

import com.bitp.model.Team;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TeamRepository extends JpaRepository<Team, Integer> {
    List<Team> findAllByOrderByNameAsc(); // Add this method
}