// VoterRepository.java
package com.bitp.repository;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.bitp.model.Voter;

public interface VoterRepository extends JpaRepository<Voter, Integer> {
    Optional<Voter> findByMatricNo(String matricNo);
}