// VoteRepository.java
package com.bitp.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.bitp.model.*;

public interface VoteRepository extends JpaRepository<Vote, Integer> {
    boolean existsByVoter(Voter v);
}