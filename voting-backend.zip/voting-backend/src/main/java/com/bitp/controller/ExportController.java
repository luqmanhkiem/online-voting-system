package com.bitp.controller;

import com.bitp.repository.TeamRepository;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.*;
import com.google.firebase.cloud.FirestoreClient;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/staff")
public class ExportController {

    private final TeamRepository repo;

    public ExportController(TeamRepository repo) {
        this.repo = repo;
    }

    @PostMapping("/export")
    public Map<String, String> exportToFirestore() {
        try {
            Firestore db = FirestoreClient.getFirestore();
            CollectionReference votesRef = db.collection("teamVotes");

            // Clear existing data
            ApiFuture<QuerySnapshot> future = votesRef.get();
            List<QueryDocumentSnapshot> docs = future.get().getDocuments();
            for (QueryDocumentSnapshot doc : docs) {
                doc.getReference().delete();
            }

            // Upload team data
            repo.findAll().forEach(t -> {
                Map<String, Object> data = new HashMap<>();
                data.put("name", t.getName());
                data.put("votes", t.getVotes());
                votesRef.add(data);
            });

            return Map.of("sheetUrl", "https://console.firebase.google.com/project/votingexportsystem/firestore/data/~2FteamVotes");

        } catch (Exception e) {
            e.printStackTrace();
            return Map.of("error", "Failed to export data.");
        }
    }
}
