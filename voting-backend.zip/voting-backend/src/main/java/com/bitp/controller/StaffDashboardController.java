package com.bitp.controller;

import com.bitp.model.Team;
import com.bitp.repository.TeamRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/staff")
public class StaffDashboardController {
    private final TeamRepository repo;

    public StaffDashboardController(TeamRepository repo) {
        this.repo = repo;
    }

    @GetMapping("/teams")
    public List<Team> teams() {
        return repo.findAll();
    }
}
