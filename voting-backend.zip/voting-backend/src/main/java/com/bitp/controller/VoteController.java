package com.bitp.controller;

import com.bitp.model.Team;
import com.bitp.model.Vote;
import com.bitp.model.Voter;
import com.bitp.repository.TeamRepository;
import com.bitp.repository.VoteRepository;
import com.bitp.repository.VoterRepository;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class VoteController {
    private final TeamRepository teamRepo;
    private final VoterRepository voterRepo;
    private final VoteRepository voteRepo;

    public VoteController(TeamRepository teamRepo, VoterRepository voterRepo, VoteRepository voteRepo) {
        this.teamRepo = teamRepo;
        this.voterRepo = voterRepo;
        this.voteRepo = voteRepo;
    }

    @PostMapping("/vote")
    public Object vote(@RequestParam Integer teamId, @RequestHeader("Authorization") String token) {
        String matricNo = token.replace("Bearer ", "").trim();
        Voter voter = voterRepo.findByMatricNo(matricNo)
                .orElseThrow(() -> new RuntimeException("Invalid voter"));

        if (voter.getVoted()) {
            throw new RuntimeException("Already voted");
        }

        Team team = teamRepo.findById(teamId)
                .orElseThrow(() -> new RuntimeException("Team not found"));

        voter.setVoted(true);
        team.setVotes(team.getVotes() + 1);

        voteRepo.save(new Vote(team, voter));
        voterRepo.save(voter);
        teamRepo.save(team);

        return Map.of("message", "Vote successful");
    }
}
