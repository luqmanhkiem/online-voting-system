package com.bitp.controller;

import com.bitp.dto.LoginRequest;
import com.bitp.model.Voter;
import com.bitp.repository.VoterRepository;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class AuthController {
    private final VoterRepository repo;

    public AuthController(VoterRepository repo) {
        this.repo = repo;
    }

    @PostMapping("/login")
    public Object login(@RequestBody LoginRequest req) {
        System.out.println("Login attempt for matric: " + req.matricNo());
        return repo.findByMatricNo(req.matricNo())
                .map(v -> Map.of("token", v.getMatricNo()))
                .orElseThrow(() -> new RuntimeException("Invalid matric number"));
    }
}
