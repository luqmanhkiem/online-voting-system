package com.bitp.controller;

import com.bitp.model.Team;
import com.bitp.repository.TeamRepository;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
@RequestMapping("/api")
public class TeamController {
    private final TeamRepository teamRepo;

    public TeamController(TeamRepository teamRepo) {
        this.teamRepo = teamRepo;
    }

    @GetMapping("/teams")
    public List<Team> getTeams() {
        return teamRepo.findAll();
    }
}