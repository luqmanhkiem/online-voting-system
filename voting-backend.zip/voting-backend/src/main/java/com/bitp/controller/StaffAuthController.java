package com.bitp.controller;

import com.bitp.dto.StaffLoginRequest;
import com.bitp.repository.StaffRepository;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/staff")
public class StaffAuthController {
    private final StaffRepository repo;

    public StaffAuthController(StaffRepository repo) {
        this.repo = repo;
    }

    @PostMapping("/login")
    public Object login(@RequestBody StaffLoginRequest req) {
        return repo.findByUsername(req.username().trim())
                   .filter(s -> s.getPassword().equals(req.password().trim()))
                   .map(s -> Map.of("token", s.getUsername()))
                   .orElseThrow(() -> new RuntimeException("Invalid credentials"));
    }
}
