package com.bitp.dto;

public record StaffLoginRequest(String username, String password) {}
