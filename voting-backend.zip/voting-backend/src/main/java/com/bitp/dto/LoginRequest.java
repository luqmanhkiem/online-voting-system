// LoginRequest.java
package com.bitp.dto;
public record LoginRequest(String matricNo) {}